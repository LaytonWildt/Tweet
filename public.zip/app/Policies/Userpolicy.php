<?php

namespace App\Policies;

use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class Userpolicy
{
    use HandlesAuthorization;

    public function edit(User auth(), User $user ){
        return auth()->is($user);
    }
}
