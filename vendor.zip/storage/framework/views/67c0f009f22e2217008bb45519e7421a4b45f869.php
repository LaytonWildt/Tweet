<h3 class="font-bold text-xl mb-4">Following</h3>

<ul>
<?php $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="mb-4">
    <a href="<?php echo e(route('profile', $user)); ?>" class="flex items-center text-sm">
      <img
          src="<?php echo e($user->avatar); ?>"
          alt=""
          class="rounded-full mr-3"
      >
      
      <?php echo e($user->name); ?>

    </a> 
  </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\laravel\Twitter\Twitter\resources\views/layouts/navbars/friends.blade.php ENDPATH**/ ?>