

<?php $__env->startSection('content'); ?>
    <h3>Profile page for <?php echo e($user->name); ?></h3>

    <hr>

    <?php echo $__env->make('layouts.navbars.ptimeline' ,[
        'tweets' => $user->tweets
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [
    'namePage' => 'Dashboard',
    'class' => 'login-page sidebar-mini ',
    'activePage' => 'home',
    'backgroundImage' => asset('now') . "/img/bg14.jpg",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Twitter\Twitter\resources\views/profiles/show.blade.php ENDPATH**/ ?>