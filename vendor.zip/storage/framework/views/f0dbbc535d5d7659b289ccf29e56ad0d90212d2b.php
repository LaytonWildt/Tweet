<div class="border border-gray-300 rounded-lg">
              <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo $__env->make('layouts.navbars.tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div><?php /**PATH C:\xampp\htdocs\laravel\Twitter\Twitter\resources\views/layouts/navbars/ptimeline.blade.php ENDPATH**/ ?>