@extends('layouts.app')

@section('content')
    @include('layouts.navbars.timeline')

    @include('layouts.navbars.ptimeline')
@endsection

