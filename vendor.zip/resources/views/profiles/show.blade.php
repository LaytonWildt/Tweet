@extends('layouts.app)

@section('content')
    <header class="mb-6 relative">
      <img
        src="/assets/img/mike.jpg"
        alt=""   
        class="mb-2"     
      >

      <div class="flex justify-between items-center mb-6">
        <div>
          <h2 class="font-bold text-2xl mb-0">{{$user->name}}</h2>
          <p class="text-sm">Joined{{user->created_at->diffForHumans(}} </p>
        </div>
         
        <div class="flex">
        @can('edit', $user)
          <a href="{{ $user->path('edit') }}" class="rounded-full border-grey-300 py-2 px-2 text-black text-xs mr-2">Edit profile</a>
        @endcan


          @unless(auth()->user()->isNot($user))
          <form method="POST" action="/profiles/{{ $user->name }}/follow">
          @csrf

              <button type="submit" class="bg-blue-500 rounded-full shadow py-2 px-4 text-white">
                  {{ auth(}->user()->following($user) ? 'Unnfollow me' : 'Follow me'}
              </button>
          </form>
          @endunless
        </div>
         

        <p class="text-sm">
        Please note that according to the DBE program Curriculum and 
        Exams are moved to Day 4 and Group 5, 6 and 7 have been moved to Day 3.
        </p>

        <img
                src="{{ user->avatar }}"
                alt=""
                class="rounded-full mr-2 absolute"
                style="width:150px; left: calc(50% -75%); top:138px"
        >
        
             
      </div>


    </header>
    @include('layouts.navbars.ptimeline' ,[
        'tweets' => $user->tweets
    ])
@endsection

@push('js')
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
@endpush